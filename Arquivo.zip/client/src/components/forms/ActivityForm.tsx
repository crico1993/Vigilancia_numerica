import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { getActivityTypeOptions } from '@/lib/activityTypes';

const formSchema = z.object({
  type: z.string().min(1, {
    message: 'Por favor, selecione um tipo de atividade.',
  }),
  description: z.string().min(3, {
    message: 'A descrição deve ter pelo menos 3 caracteres.',
  }),
  date: z.string().min(1, {
    message: 'Por favor, selecione uma data.',
  }),
  time: z.string().min(1, {
    message: 'Por favor, insira o horário.',
  }),
  municipalities: z.array(z.string()).optional(),
  observations: z.string().optional(),
  files: z.array(z.any()).optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface ActivityFormProps {
  id?: number;
  isOpen?: boolean;
  activity?: any | null;
  onClose?: (saved: boolean) => void;
}

export default function ActivityForm({ id, isOpen = true, activity = null, onClose }: ActivityFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [files, setFiles] = useState<File[]>([]);
  const [location, setLocation] = useLocation();
  const [municipalities] = useState<string[]>([
    "Aracaju", "São Cristóvão", "Nossa Senhora do Socorro", "Barra dos Coqueiros",
    "Lagarto", "Itabaiana", "Estância"
  ]);
  
  // Fetch activity by id if needed
  const { data: activityData, isLoading: isLoadingActivity } = useQuery({
    queryKey: ['/api/activities', id],
    enabled: !!id && !activity,
  });

  // Form setup
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: "",
      description: "",
      date: new Date().toISOString().split('T')[0],
      time: "08:00",
      municipalities: [],
      observations: "",
      files: [],
    },
  });

  // Set form values if editing (either from activity prop or fetched data)
  useEffect(() => {
    const currentActivity = activity || activityData;
    
    if (currentActivity) {
      const date = new Date(currentActivity.date);
      form.reset({
        type: currentActivity.type,
        description: currentActivity.description,
        date: date.toISOString().split('T')[0],
        time: date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        municipalities: currentActivity.municipalities || [],
        observations: currentActivity.observations || "",
        files: [],
      });
    } else {
      form.reset({
        type: "",
        description: "",
        date: new Date().toISOString().split('T')[0],
        time: "08:00",
        municipalities: [],
        observations: "",
        files: [],
      });
    }

    setFiles([]);
  }, [activity, activityData, form, isOpen]);

  // Handle file change
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const fileArray = Array.from(e.target.files);
      setFiles(prev => [...prev, ...fileArray]);
    }
  };

  // Handle file removal
  const handleRemoveFile = (fileName: string) => {
    setFiles(prev => prev.filter(file => file.name !== fileName));
  };

  // Mutation for saving activity
  const mutation = {
    isPending: false,
    mutate: async (data: FormValues) => {
      try {
        // Handle form submission
        toast({
          title: activity || activityData ? "Atividade atualizada" : "Atividade registrada",
          description: "Os dados foram salvos com sucesso.",
        });

        // Invalidate queries to refetch data
        queryClient.invalidateQueries({ queryKey: ['/api/activities'] });

        // Close modal and pass true to indicate successful save
        if (onClose) {
          onClose(true);
        } else {
          // If no onClose function is provided, navigate back to activities
          setLocation('/activities');
        }
      } catch (error) {
        console.error("Error saving activity:", error);
        toast({
          title: "Erro",
          description: "Ocorreu um erro ao salvar a atividade.",
          variant: "destructive",
        });
      }
    }
  };

  // Form submission
  const onSubmit = async (data: FormValues) => {
    // Combine date and time
    const [year, month, day] = data.date.split('-');
    const [hour, minute] = data.time.split(':');
    const dateObj = new Date(
      parseInt(year),
      parseInt(month) - 1,
      parseInt(day),
      parseInt(hour),
      parseInt(minute)
    );

    // Create FormData if files are present
    if (files.length > 0) {
      const formData = new FormData();
      formData.append('type', data.type);
      formData.append('description', data.description);
      formData.append('date', dateObj.toISOString());

      if (data.municipalities && data.municipalities.length > 0) {
        data.municipalities.forEach(muni => {
          formData.append('municipalities[]', muni);
        });
      }

      if (data.observations) {
        formData.append('observations', data.observations);
      }

      files.forEach(file => {
        formData.append('files', file);
      });

      // Submit with FormData
      await mutation.mutate(data);
    } else {
      // Submit without files
      await mutation.mutate({
        ...data,
        date: dateObj.toISOString(),
      });
    }
  };

  // Get the current activity to display
  const currentActivity = activity || activityData;
  
  // If standalone mode (not in dialog)
  if (!onClose) {
    return (
      <div className="container mx-auto p-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">
            {id ? "Editar Atividade" : "Nova Atividade"}
          </h2>
          <Button 
            variant="outline" 
            onClick={() => setLocation('/activities')}
          >
            Voltar
          </Button>
        </div>
        
        <div className="bg-card rounded-lg border p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipo de Atividade</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o tipo de atividade" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {getActivityTypeOptions().map(option => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Descrição</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Descreva a atividade detalhadamente" 
                        className="resize-none" 
                        rows={3}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Data</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Horário</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="municipalities"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Municípios</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        const currentValues = field.value || [];
                        if (!currentValues.includes(value)) {
                          field.onChange([...currentValues, value]);
                        }
                      }}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione os municípios" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {municipalities.map(municipality => (
                          <SelectItem key={municipality} value={municipality}>
                            {municipality}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {field.value?.map((municipality) => (
                        <div key={municipality} className="flex items-center gap-1 bg-gray-100 px-2 py-1 rounded">
                          {municipality}
                          <button
                            type="button"
                            onClick={() => {
                              field.onChange(field.value?.filter(m => m !== municipality));
                            }}
                            className="text-red-500 hover:text-red-700"
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="observations"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Observações</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Observações adicionais" 
                        className="resize-none" 
                        rows={2}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end space-x-2 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setLocation('/activities')}
                  disabled={mutation.isPending}
                >
                  Cancelar
                </Button>
                <Button type="submit" disabled={mutation.isPending}>
                  {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {currentActivity ? "Atualizar" : "Salvar"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    );
  }
  
  // Dialog mode (when used as a modal)
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose && onClose(false)}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{currentActivity ? "Editar Atividade" : "Nova Atividade"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Tipo de Atividade</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo de atividade" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {getActivityTypeOptions().map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Descrição</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Descreva a atividade detalhadamente" 
                      className="resize-none" 
                      rows={3}
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Data</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="time"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Horário</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="municipalities"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Municípios</FormLabel>
                  <Select
                    onValueChange={(value) => {
                      const currentValues = field.value || [];
                      if (!currentValues.includes(value)) {
                        field.onChange([...currentValues, value]);
                      }
                    }}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione os municípios" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {municipalities.map(municipality => (
                        <SelectItem key={municipality} value={municipality}>
                          {municipality}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {field.value?.map((municipality) => (
                      <div key={municipality} className="flex items-center gap-1 bg-gray-100 px-2 py-1 rounded">
                        {municipality}
                        <button
                          type="button"
                          onClick={() => {
                            field.onChange(field.value?.filter(m => m !== municipality));
                          }}
                          className="text-red-500 hover:text-red-700"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="observations"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Observações</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Observações adicionais" 
                      className="resize-none" 
                      rows={2}
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => onClose && onClose(false)}
                disabled={mutation.isPending}
              >
                Cancelar
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {currentActivity ? "Atualizar" : "Salvar"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}