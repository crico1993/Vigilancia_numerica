import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express from "express";
import session from "express-session";
import { z } from "zod";
import { 
  loginSchema, 
  insertUserSchema, 
  insertActivitySchema, 
  insertLogSchema,
  ActivityType, 
  UserRole 
} from "@shared/schema";
import { zValidationErrorToResponse } from "./utils";

// Define a type for our session data
declare module "express-session" {
  interface SessionData {
    userId: number;
    userRole: string;
    userName: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Create the HTTP server
  const httpServer = createServer(app);

  // Configure session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "vigilanciaemNumeros", 
      resave: true, // Alterado para true para garantir que a sessão seja salva
      saveUninitialized: false,
      cookie: { 
        secure: false, // Alterado para false para permitir cookies sem HTTPS em desenvolvimento
        httpOnly: true,
        sameSite: 'lax',
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
      }
    })
  );

  // Authentication middleware
  const authenticate = (req: Request, res: Response, next: () => void) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Não autenticado. Faça login para continuar." });
    }
    next();
  };

  // Role-based authorization middleware
  const authorize = (roles: UserRole[]) => {
    return (req: Request, res: Response, next: () => void) => {
      if (!req.session.userRole || !roles.includes(req.session.userRole as UserRole)) {
        return res.status(403).json({ message: "Acesso não autorizado." });
      }
      next();
    };
  };

  // AUTH ROUTES
  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      
      const user = await storage.validateCredentials(
        validatedData.email,
        validatedData.password
      );
      
      if (!user) {
        return res.status(401).json({ message: "Email ou senha inválidos." });
      }

      if (!user.active) {
        return res.status(403).json({ message: "Usuário desativado. Contate o administrador." });
      }
      
      if (!user.approved && user.role !== UserRole.ADMIN) {
        return res.status(403).json({ message: "Seu cadastro está aguardando aprovação pelo administrador." });
      }

      // Set session data
      req.session.userId = user.id;
      req.session.userRole = user.role;
      req.session.userName = user.name;

      // Log the login
      await storage.createLog({
        userId: user.id,
        action: "LOGIN",
        details: { ip: req.ip }
      });

      return res.status(200).json({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json(zValidationErrorToResponse(error));
      }
      return res.status(500).json({ message: "Erro no servidor." });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    if (req.session.userId) {
      // Log the logout
      storage.createLog({
        userId: req.session.userId,
        action: "LOGOUT",
        details: { ip: req.ip }
      });
    }
    
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Erro ao fazer logout." });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logout realizado com sucesso." });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Não autenticado" });
    }

    const user = await storage.getUser(req.session.userId);
    if (!user) {
      // Session exists but user doesn't - clear session
      req.session.destroy(() => {});
      return res.status(401).json({ message: "Usuário não encontrado" });
    }

    return res.status(200).json({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    });
  });

  // Rota pública para registro de novos usuários
  app.post("/api/users/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse({
        ...req.body,
        role: UserRole.SERVER, // Sempre registra como SERVER por segurança
        approved: false // Novo usuário inicia como não aprovado
      });
      
      // Verifica se o email já existe
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email já cadastrado. Escolha outro email." });
      }

      const user = await storage.createUser(validatedData);
      
      // Registra o log de criação de usuário
      await storage.createLog({
        userId: user.id,
        action: "SELF_REGISTER",
        details: { ip: req.ip }
      });

      return res.status(201).json({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        active: user.active,
        approved: user.approved,
        message: "Cadastro realizado com sucesso! Aguarde a aprovação do administrador para acessar o sistema."
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json(zValidationErrorToResponse(error));
      }
      return res.status(500).json({ message: "Erro ao criar usuário." });
    }
  });

  // USER ROUTES
  app.get("/api/users", authenticate, authorize([UserRole.ADMIN]), async (req, res) => {
    try {
      const users = await storage.getUsers();
      // Don't return password hash
      const safeUsers = users.map(user => ({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        active: user.active,
        createdAt: user.createdAt
      }));
      
      return res.status(200).json(safeUsers);
    } catch (error) {
      return res.status(500).json({ message: "Erro ao obter usuários." });
    }
  });

  app.post("/api/users", authenticate, authorize([UserRole.ADMIN]), async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if email already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email já cadastrado." });
      }

      const user = await storage.createUser(validatedData);
      
      // Log the user creation
      await storage.createLog({
        userId: req.session.userId!,
        action: "CREATE_USER",
        details: { targetUserId: user.id, targetEmail: user.email }
      });

      return res.status(201).json({
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        active: user.active
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json(zValidationErrorToResponse(error));
      }
      return res.status(500).json({ message: "Erro ao criar usuário." });
    }
  });

  app.patch("/api/users/:id", authenticate, authorize([UserRole.ADMIN]), async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "ID de usuário inválido." });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado." });
      }

      // Only allow certain fields to be updated
      const allowedFields = ["name", "role", "active", "password"];
      const updateData = Object.keys(req.body)
        .filter(key => allowedFields.includes(key))
        .reduce((obj, key) => {
          obj[key] = req.body[key];
          return obj;
        }, {} as any);

      const updatedUser = await storage.updateUser(userId, updateData);
      
      // Log the user update
      await storage.createLog({
        userId: req.session.userId!,
        action: "UPDATE_USER",
        details: { targetUserId: userId, fields: Object.keys(updateData) }
      });

      return res.status(200).json({
        id: updatedUser!.id,
        name: updatedUser!.name,
        email: updatedUser!.email,
        role: updatedUser!.role,
        active: updatedUser!.active
      });
    } catch (error) {
      return res.status(500).json({ message: "Erro ao atualizar usuário." });
    }
  });

  app.post("/api/users/reset-password/:id", authenticate, authorize([UserRole.ADMIN]), async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "ID de usuário inválido." });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado." });
      }

      // Validate new password
      const { password } = req.body;
      if (!password || typeof password !== 'string' || password.length < 6) {
        return res.status(400).json({ message: "Senha inválida. Deve ter pelo menos 6 caracteres." });
      }

      await storage.updateUser(userId, { password });
      
      // Log the password reset
      await storage.createLog({
        userId: req.session.userId!,
        action: "RESET_PASSWORD",
        details: { targetUserId: userId }
      });

      return res.status(200).json({ message: "Senha redefinida com sucesso." });
    } catch (error) {
      return res.status(500).json({ message: "Erro ao redefinir senha." });
    }
  });

  // ACTIVITY ROUTES
  app.get("/api/activities", authenticate, async (req, res) => {
    try {
      let activities = [];
      
      // Filter by user if not a manager/admin
      if (req.session.userRole === UserRole.SERVER) {
        activities = await storage.getActivitiesByUserId(req.session.userId!);
      } else {
        activities = await storage.getActivities();
      }
      
      // Apply type filter if provided
      const typeFilter = req.query.type as string;
      if (typeFilter && Object.values(ActivityType).includes(typeFilter as ActivityType)) {
        activities = activities.filter(a => a.type === typeFilter);
      }
      
      // Apply date filters if provided
      const startDateStr = req.query.startDate as string;
      const endDateStr = req.query.endDate as string;
      
      if (startDateStr && endDateStr) {
        const startDate = new Date(startDateStr);
        const endDate = new Date(endDateStr);
        
        if (!isNaN(startDate.getTime()) && !isNaN(endDate.getTime())) {
          activities = activities.filter(a => {
            const activityDate = new Date(a.date);
            return activityDate >= startDate && activityDate <= endDate;
          });
        }
      }
      
      return res.status(200).json(activities);
    } catch (error) {
      return res.status(500).json({ message: "Erro ao obter atividades." });
    }
  });

  app.post("/api/activities", authenticate, async (req, res) => {
    try {
      const validatedData = insertActivitySchema.parse({
        ...req.body,
        userId: req.session.userId
      });
      
      const activity = await storage.createActivity(validatedData);
      
      // Log the activity creation
      await storage.createLog({
        userId: req.session.userId!,
        action: "CREATE_ACTIVITY",
        details: { activityId: activity.id, activityType: activity.type }
      });

      return res.status(201).json(activity);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json(zValidationErrorToResponse(error));
      }
      return res.status(500).json({ message: "Erro ao criar atividade." });
    }
  });

  app.get("/api/activities/:id", authenticate, async (req, res) => {
    try {
      const activityId = parseInt(req.params.id);
      if (isNaN(activityId)) {
        return res.status(400).json({ message: "ID de atividade inválido." });
      }

      const activity = await storage.getActivity(activityId);
      if (!activity) {
        return res.status(404).json({ message: "Atividade não encontrada." });
      }

      // Check if user is permitted to see this activity
      if (req.session.userRole === UserRole.SERVER && activity.userId !== req.session.userId) {
        return res.status(403).json({ message: "Acesso não autorizado a esta atividade." });
      }

      return res.status(200).json(activity);
    } catch (error) {
      return res.status(500).json({ message: "Erro ao obter atividade." });
    }
  });

  app.patch("/api/activities/:id", authenticate, async (req, res) => {
    try {
      const activityId = parseInt(req.params.id);
      if (isNaN(activityId)) {
        return res.status(400).json({ message: "ID de atividade inválido." });
      }

      const activity = await storage.getActivity(activityId);
      if (!activity) {
        return res.status(404).json({ message: "Atividade não encontrada." });
      }

      // Only owner or admin can edit
      if (activity.userId !== req.session.userId && req.session.userRole !== UserRole.ADMIN) {
        return res.status(403).json({ message: "Somente o criador da atividade ou um administrador pode editá-la." });
      }

      // Don't allow changing userId
      const { userId, ...updateData } = req.body;
      
      const updatedActivity = await storage.updateActivity(activityId, updateData);
      
      // Log the activity update
      await storage.createLog({
        userId: req.session.userId!,
        action: "UPDATE_ACTIVITY",
        details: { activityId, fields: Object.keys(updateData) }
      });

      return res.status(200).json(updatedActivity);
    } catch (error) {
      return res.status(500).json({ message: "Erro ao atualizar atividade." });
    }
  });

  app.delete("/api/activities/:id", authenticate, async (req, res) => {
    try {
      const activityId = parseInt(req.params.id);
      if (isNaN(activityId)) {
        return res.status(400).json({ message: "ID de atividade inválido." });
      }

      const activity = await storage.getActivity(activityId);
      if (!activity) {
        return res.status(404).json({ message: "Atividade não encontrada." });
      }

      // Only owner or admin can delete
      if (activity.userId !== req.session.userId && req.session.userRole !== UserRole.ADMIN) {
        return res.status(403).json({ message: "Somente o criador da atividade ou um administrador pode excluí-la." });
      }

      await storage.deleteActivity(activityId);
      
      // Log the activity deletion
      await storage.createLog({
        userId: req.session.userId!,
        action: "DELETE_ACTIVITY",
        details: { activityId, activityType: activity.type }
      });

      return res.status(200).json({ message: "Atividade excluída com sucesso." });
    } catch (error) {
      return res.status(500).json({ message: "Erro ao excluir atividade." });
    }
  });

  // DASHBOARD STATISTICS ROUTES
  app.get("/api/statistics", authenticate, async (req, res) => {
    try {
      let activities = [];
      
      // Filter by user if not a manager
      if (req.session.userRole === UserRole.SERVER) {
        activities = await storage.getActivitiesByUserId(req.session.userId!);
      } else {
        activities = await storage.getActivities();
      }
      
      // Calculate statistics
      const stats = {
        totalActivities: activities.length,
        byType: {} as Record<string, number>,
        byMonth: {} as Record<string, number>,
        recentTrend: 0 
      };
      
      // Count by type
      activities.forEach(activity => {
        stats.byType[activity.type] = (stats.byType[activity.type] || 0) + 1;
      });
      
      // Count by month
      activities.forEach(activity => {
        const date = new Date(activity.date);
        const monthYear = `${date.getFullYear()}-${date.getMonth()+1}`;
        stats.byMonth[monthYear] = (stats.byMonth[monthYear] || 0) + 1;
      });
      
      // Calculate trend (simple comparison to previous period)
      const now = new Date();
      const thisMonth = now.getMonth();
      const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1;
      const thisYear = now.getFullYear();
      const lastYear = thisMonth === 0 ? thisYear - 1 : thisYear;
      
      const thisMonthKey = `${thisYear}-${thisMonth+1}`;
      const lastMonthKey = `${lastYear}-${lastMonth+1}`;
      
      const thisMonthCount = stats.byMonth[thisMonthKey] || 0;
      const lastMonthCount = stats.byMonth[lastMonthKey] || 0;
      
      if (lastMonthCount > 0) {
        stats.recentTrend = ((thisMonthCount - lastMonthCount) / lastMonthCount) * 100;
      }
      
      return res.status(200).json(stats);
    } catch (error) {
      return res.status(500).json({ message: "Erro ao obter estatísticas." });
    }
  });

  // LOGS ROUTE (admin only)
  app.get("/api/logs", authenticate, authorize([UserRole.ADMIN]), async (req, res) => {
    try {
      const logs = await storage.getLogs();
      return res.status(200).json(logs);
    } catch (error) {
      return res.status(500).json({ message: "Erro ao obter logs." });
    }
  });

  return httpServer;
}
