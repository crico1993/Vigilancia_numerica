import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Form, FormControl, FormField, FormItem, FormLabel } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  DownloadIcon, 
  CalendarIcon, 
  BarChart4, 
  FileText, 
  CheckCircle2, 
  Loader2
} from 'lucide-react';
import { 
  BarChartComponent, 
  PieChartComponent, 
  LineChartComponent 
} from '@/components/ui/chart';
import { getActivityTypeOptions, dateRangeOptions } from '@/lib/activityTypes';
import { Activity } from '@shared/schema';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';

// Report generation form schema
const reportFormSchema = z.object({
  dateRange: z.string(),
  startDate: z.date().optional(),
  endDate: z.date().optional(),
  activityType: z.string().default('all'),
  format: z.enum(['pdf', 'excel']),
  includeCharts: z.boolean().default(true),
  includeDetails: z.boolean().default(true),
});

type ReportFormValues = z.infer<typeof reportFormSchema>;

export default function Reports() {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState('generate');
  
  // Fetch data
  const { data: activitiesData, isLoading } = useQuery({
    queryKey: ['/api/activities'],
  });
  
  // Fetch statistics
  const { data: statsData, isLoading: statsLoading } = useQuery({
    queryKey: ['/api/statistics'],
  });
  
  // Form setup
  const form = useForm<ReportFormValues>({
    resolver: zodResolver(reportFormSchema),
    defaultValues: {
      dateRange: '30',
      activityType: 'all',
      format: 'pdf',
      includeCharts: true,
      includeDetails: true,
    },
  });
  
  // Watch for changes to dateRange to update the date fields
  const dateRange = form.watch('dateRange');
  const startDate = form.watch('startDate');
  const endDate = form.watch('endDate');
  
  // Handle form submission
  const onSubmit = async (values: ReportFormValues) => {
    setIsGenerating(true);
    
    try {
      // This would connect to a real API endpoint
      // that generates and returns the report
      setTimeout(() => {
        toast({
          title: 'Relatório gerado com sucesso',
          description: `Seu relatório foi gerado no formato ${values.format.toUpperCase()}.`,
          duration: 5000,
        });
        setIsGenerating(false);
      }, 2000);
    } catch (error) {
      toast({
        title: 'Erro ao gerar relatório',
        description: 'Ocorreu um erro ao tentar gerar o relatório. Tente novamente.',
        variant: 'destructive',
      });
      setIsGenerating(false);
    }
  };
  
  // Prepare chart data
  const prepareMonthlyData = () => {
    if (!activitiesData) return [];
    
    const monthCounts: Record<string, number> = {};
    
    activitiesData.forEach((activity: Activity) => {
      const date = new Date(activity.date);
      const monthYear = format(date, 'MMM yyyy', { locale: ptBR });
      
      monthCounts[monthYear] = (monthCounts[monthYear] || 0) + 1;
    });
    
    return Object.entries(monthCounts).map(([month, count]) => ({
      month,
      quantidade: count
    }));
  };
  
  const prepareTypeData = () => {
    if (!statsData?.byType) return [];
    
    return Object.entries(statsData.byType).map(([type, count]) => {
      const label = getActivityTypeOptions().find(opt => opt.value === type)?.label || type;
      return {
        name: label,
        value: count
      };
    });
  };
  
  // Calculate custom date ranges
  const showCustomDateFields = dateRange === 'custom';
  
  return (
    <MainLayout title="Relatórios">
      <Tabs 
        value={activeTab} 
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="generate">Gerar Relatório</TabsTrigger>
          <TabsTrigger value="view">Visualizar Dados</TabsTrigger>
        </TabsList>
        
        <TabsContent value="generate" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Geração de Relatórios</CardTitle>
              <CardDescription>
                Configure os parâmetros para gerar relatórios personalizados das atividades registradas.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="dateRange"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Período</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione o período" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {dateRangeOptions.map(option => (
                                <SelectItem key={option.value} value={option.value}>
                                  {option.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="activityType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo de Atividade</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione o tipo" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="all">Todos os tipos</SelectItem>
                              {getActivityTypeOptions().map(option => (
                                <SelectItem key={option.value} value={option.value}>
                                  {option.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  {showCustomDateFields && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="startDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Data Inicial</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant="outline"
                                    className={cn(
                                      "w-full pl-3 text-left font-normal",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {field.value ? format(field.value, 'PPP', { locale: ptBR }) : "Selecione uma data"}
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="endDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>Data Final</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant="outline"
                                    className={cn(
                                      "w-full pl-3 text-left font-normal",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {field.value ? format(field.value, 'PPP', { locale: ptBR }) : "Selecione uma data"}
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="start">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                          </FormItem>
                        )}
                      />
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="format"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Formato do Relatório</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Selecione o formato" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="pdf">PDF</SelectItem>
                              <SelectItem value="excel">Excel</SelectItem>
                            </SelectContent>
                          </Select>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="includeCharts"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Incluir Gráficos</FormLabel>
                            <FormDescription>
                              Adicionar visualizações gráficas ao relatório
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="includeDetails"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Incluir Detalhes</FormLabel>
                            <FormDescription>
                              Adicionar descrições detalhadas de cada atividade
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isGenerating || (showCustomDateFields && (!startDate || !endDate))}
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Gerando relatório...
                      </>
                    ) : (
                      <>
                        <DownloadIcon className="mr-2 h-4 w-4" />
                        Gerar Relatório
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="view" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total de Atividades</CardTitle>
              </CardHeader>
              <CardContent>
                {statsLoading ? (
                  <Skeleton className="h-8 w-20" />
                ) : (
                  <div className="text-3xl font-bold">
                    {statsData?.totalActivities || 0}
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Tipos de Atividades</CardTitle>
              </CardHeader>
              <CardContent>
                {statsLoading ? (
                  <Skeleton className="h-8 w-20" />
                ) : (
                  <div className="text-3xl font-bold">
                    {Object.keys(statsData?.byType || {}).length || 0}
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Tendência de Crescimento</CardTitle>
              </CardHeader>
              <CardContent>
                {statsLoading ? (
                  <Skeleton className="h-8 w-20" />
                ) : (
                  <div className="text-3xl font-bold flex items-center">
                    {statsData?.recentTrend > 0 ? (
                      <span className="text-green-500">+{statsData?.recentTrend.toFixed(1)}%</span>
                    ) : (
                      <span className="text-red-500">{statsData?.recentTrend.toFixed(1)}%</span>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Atividades por Mês</CardTitle>
                <CardDescription>Total de atividades registradas por período</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="h-[350px] flex items-center justify-center">
                    <Skeleton className="h-[300px] w-full rounded-lg" />
                  </div>
                ) : (
                  <div className="h-[350px]">
                    <BarChartComponent
                      data={prepareMonthlyData()}
                      xDataKey="month"
                      barDataKey="quantidade"
                      barColor="var(--primary)"
                      height={350}
                    />
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Distribuição por Tipo</CardTitle>
                <CardDescription>Proporção de cada tipo de atividade</CardDescription>
              </CardHeader>
              <CardContent>
                {statsLoading ? (
                  <div className="h-[350px] flex items-center justify-center">
                    <Skeleton className="h-[300px] w-full rounded-lg" />
                  </div>
                ) : (
                  <div className="h-[350px]">
                    <PieChartComponent
                      data={prepareTypeData()}
                      nameKey="name"
                      dataKey="value"
                      height={350}
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
}

// Helper FormDescription component
function FormDescription({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-sm text-muted-foreground">
      {children}
    </p>
  );
}
