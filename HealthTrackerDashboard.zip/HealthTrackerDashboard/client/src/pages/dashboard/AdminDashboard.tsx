import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import MainLayout from "@/components/layout/MainLayout";
import { useAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { User } from "@shared/schema";
import { ActivityWithMeta } from "@/types";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { UserPlus, UserCheck, UserX, Activity, RefreshCw } from "lucide-react";
import ServerDashboard from "@/components/dashboard/ServerDashboard";
import ManagerDashboard from "@/components/dashboard/ManagerDashboard";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Edit, KeyRound } from "lucide-react";


export default function AdminDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    if (!user) {
      setLocation("/login");
    }
  }, [user, setLocation]);

  // Fetch system statistics
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });

  const { data: activities = [] } = useQuery<ActivityWithMeta[]>({
    queryKey: ['/api/activities'],
  });

  interface LogEntry {
    id: number;
    action: string;
    userId: number;
    details?: any;
    createdAt: string;
  }

  const { data: logs = [] } = useQuery<LogEntry[]>({
    queryKey: ['/api/logs'],
  });

  // Calculate user statistics
  const pendingApprovals = users.filter((u) => !u.approved).length || 0;
  const activeUsers = users.filter((u) => u.active).length || 0;
  const totalUsers = users.length || 0;

  // Recent logs
  const recentLogs = logs.slice(0, 10);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const handleEditUser = (user: User) => {
    // Placeholder: Implement user edit logic
    console.log("Edit user:", user);
  };

  const handleResetPassword = (user: User) => {
    // Placeholder: Implement reset password logic
    console.log("Reset password for user:", user);
  };


  return (
    <MainLayout title="Dashboard do Administrador">
      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="server-view">Visão Servidor</TabsTrigger>
            <TabsTrigger value="manager-view">Visão Gestor</TabsTrigger>
            <TabsTrigger value="users-view">Usuários</TabsTrigger> {/* Added Users Tab */}
          </TabsList>

          <div className="flex space-x-2">
            <Button onClick={() => setLocation("/users")} variant="outline">
              <UserPlus className="mr-2 h-4 w-4" />
              Gerenciar Usuários
            </Button>
            <Button onClick={() => setLocation("/logs")} variant="outline">
              <Activity className="mr-2 h-4 w-4" />
              Ver Logs Completos
            </Button>
          </div>
        </div>

        <TabsContent value="overview" className="space-y-6">
          {/* Admin Overview */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Usuários Pendentes</CardTitle>
                <CardDescription>Aprovações pendentes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{pendingApprovals}</div>
                {pendingApprovals > 0 && (
                  <Button 
                    onClick={() => setLocation("/users/pending")} 
                    variant="link" 
                    className="p-0 h-auto text-blue-500"
                  >
                    Ver pendentes
                  </Button>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Usuários Ativos</CardTitle>
                <CardDescription>Do total de {totalUsers} usuários</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{activeUsers}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Atividades Registradas</CardTitle>
                <CardDescription>Total no sistema</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{activities?.length || 0}</div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Ações Rápidas</CardTitle>
              <CardDescription>Tarefas administrativas comuns</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-2 md:grid-cols-4">
              <Button onClick={() => setLocation("/users/new")} className="justify-start">
                <UserPlus className="mr-2 h-4 w-4" />
                Novo Usuário
              </Button>

              <Button onClick={() => setLocation("/users/pending")} className="justify-start">
                <UserCheck className="mr-2 h-4 w-4" />
                Aprovar Usuários
              </Button>

              <Button onClick={() => setLocation("/users")} className="justify-start">
                <RefreshCw className="mr-2 h-4 w-4" />
                Resetar Senhas
              </Button>

              <Button onClick={() => setLocation("/users")} className="justify-start">
                <UserX className="mr-2 h-4 w-4" />
                Desativar Usuários
              </Button>
            </CardContent>
          </Card>

          {/* Recent System Logs */}
          <Card>
            <CardHeader>
              <CardTitle>Logs Recentes do Sistema</CardTitle>
              <CardDescription>Últimas 10 operações realizadas</CardDescription>
            </CardHeader>
            <CardContent>
              {recentLogs.length > 0 ? (
                <div className="rounded-md border">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead>
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data/Hora</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usuário</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ação</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Detalhes</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {recentLogs.map((log) => {
                        const user = users.find((u) => u.id === log.userId);
                        return (
                          <tr key={log.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">{new Date(log.createdAt).toLocaleString()}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">{user?.name || 'Desconhecido'}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold">{log.action}</td>
                            <td className="px-6 py-4 text-sm">
                              {log.details ? JSON.stringify(log.details) : '-'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Nenhum log encontrado</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="server-view">
          <ServerDashboard />
        </TabsContent>

        <TabsContent value="manager-view">
          <ManagerDashboard />
        </TabsContent>

        <TabsContent value="users-view"> {/*Added Users View*/}
          <Card>
            <CardHeader>
              <CardTitle>Usuários</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableCaption>Lista de usuários cadastrados</TableCaption>
                <TableHead>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Perfil</TableHead>
                    <TableHead>Data de Cadastro</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ações</TableHead>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant={user.role === 'admin' ? "destructive" : user.role === 'manager' ? "warning" : "default"}>
                          {user.role === 'admin' ? 'Administrador' : user.role === 'manager' ? 'Gestor' : 'Servidor'}
                        </Badge>
                      </TableCell>
                      <TableCell>{formatDate(user.createdAt)}</TableCell>
                      <TableCell>
                        <Badge variant={user.active ? "default" : "destructive"}>
                          {user.active ? "Ativo" : "Inativo"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => handleEditUser(user)}
                          >
                            <Edit className="h-4 w-4 mr-1" /> Editar
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => handleResetPassword(user)}
                          >
                            <KeyRound className="h-4 w-4 mr-1" /> Redefinir senha
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
}